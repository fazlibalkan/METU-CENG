#include "the2.h"

#include <iostream>
//You may write your own helper functions here
int partition(unsigned short* arr, long &swap, double & avg_dist, double & max_dist, bool hoare, int size, int begin, int end, double & total_dist) {
    if (hoare == false) {
        unsigned short pivot = arr[end], temp;
        int i = begin - 1;
        
        for (int j = begin; j < end; j++) {
            if (arr[j] >= pivot) {
                i++;
                //swap
                temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
                swap++;
                if (j - i > max_dist) {
                    max_dist = j - i;
                }
                total_dist += j - i;
            }
        }
        //swap
        temp = arr[i+1];
        arr[i+1] = arr[end];
        arr[end] = temp;
        swap++;
        total_dist += end - (i + 1);
        if (end - (i + 1) > max_dist) {
            max_dist = end - (i + 1);
        }
        return i+1;
        
        
    } else {
        unsigned short pivot = arr[begin + (end - begin)/2], temp;
        int i = begin - 1;
        int j = end + 1;
        
        while (true) {
            do {
                j--;
            } while (arr[j] < pivot);
            
            do {
                i++; 
            } while (arr[i] > pivot);
            
            
            if (i < j) {
                temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
                swap++;
                
                if(j - i > max_dist){
                    max_dist = j - i;
                }
                
                total_dist += (j - i);
            } else {
                return j;
            }
        }
    }
}

void quickSortHelper(unsigned short* arr, long &swap, double & avg_dist, double & max_dist, bool hoare, int size, int begin, int end, double & total_dist)
{
    
    int pivot;
    //Your code here
    if (hoare == false) {
        if (end > begin){
            pivot = partition(arr, swap, avg_dist, max_dist, hoare, size, begin, end, total_dist);
            quickSortHelper(arr, swap, avg_dist, max_dist, hoare, size, begin, pivot-1, total_dist);
            quickSortHelper(arr, swap, avg_dist, max_dist, hoare, size, pivot+1, end, total_dist);
        }
    } else {
        if (end > begin){
            pivot = partition(arr, swap, avg_dist, max_dist, hoare, size, begin, end, total_dist);
            
            quickSortHelper(arr, swap, avg_dist, max_dist, hoare, size, begin, pivot, total_dist);
            quickSortHelper(arr, swap, avg_dist, max_dist, hoare, size, pivot+1, end, total_dist);
        }
    }
	
}

void partition3(unsigned short *arr, long &swap, long &comparison, int size, int & L, int & R) {
    unsigned short temp;
    int i = 0;
    int j = 0;
    int p = size-1, m;
    
    while (i < p) {
        if (arr[i] > arr[size - 1]) {
            temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            
            swap++;
            comparison++;
            
            i++;
            j++;
        } else if (arr[i] == arr[size - 1]) {
            comparison += 2;
            p--;
            
            temp = arr[i];
            arr[i] = arr[p];
            arr[p] = temp;
            swap++;
        } else {
            comparison += 2;
            i++;
        }
    }
    
    if (p - j > size - p) {
        m = size - p;
    } else {
        m = p - j;
    }
    

    for (int a = 0; a < m; a++) {
        swap++;
        temp = arr[j + a];
        arr[j + a] = arr[size - m + a];
        arr[size - m + a] = temp;
        
    }
    
    L = j;
    R = p - j;
    
}


void quicksort3Helper(unsigned short *arr, long &swap, long &comparison, int size,  int & L, int & R) {
    if (size > 1) {
        int L = 0, R = size -1;
        partition3(arr, swap, comparison, size, L, R);
        quicksort3Helper(arr, swap, comparison, L, L, R);
        quicksort3Helper(arr + size - R, swap, comparison, R, L, R);
    }
}

void quickSort(unsigned short* arr, long &swap, double & avg_dist, double & max_dist, bool hoare, int size)
{
    double total_dist = 0;
    //Your code here
    if (hoare == false) {
        if (size > 1) {
            quickSortHelper(arr, swap, avg_dist, max_dist, hoare, size, 0, size -1, total_dist);
            if (swap != 0) {
                avg_dist = total_dist / swap;
            } else {
                avg_dist = 0;
            }
            
        }
    } else {
        if (size > 1) {
            quickSortHelper(arr, swap, avg_dist, max_dist, true, size, 0, size -1, total_dist);
            if (swap != 0) {
                avg_dist = total_dist / swap;
            } else {
                avg_dist = 0;
            }
        }  
    }
	
}

void quickSort3(unsigned short *arr, long &swap, long &comparison, int size) {
    if (size > 1) {
        int L,R;
        quicksort3Helper(arr, swap, comparison, size, L, R);
    }
}
