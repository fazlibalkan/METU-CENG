#include "the6.h"
// Don't add any additional includes

/*
  N: Number of racers
  updates: Updates you have heard
*/

std::unordered_map<int, bool> visited;
std::unordered_map<int, std::vector<int>> graph;
std::vector<int> s;

void dfs(int u)
{
    visited[u] = 1;
    int size = graph[u].size();

    for (int i=0; i < size; i++) {
        if (visited[graph[u][i]] == 0) {
            dfs(graph[u][i]);
        }
    }

    s.push_back(u);
}

std::pair<bool, std::vector<int>>
RaceResult(int N, std::vector<std::pair<int, int>> updates) {
    bool b = true;
    std::vector<int> result;
    std::vector<int> falseresult;
    int size;
    int veclen = updates.size();
    int max = 0;

    int pos[N];

    int p, c;


    for (int i = 0; i < N; i++) {
        visited[i] = false;
    }

    for (int i = 0; i < veclen; i++) {
        graph[updates[i].first].push_back(updates[i].second);
        if (max < updates[i].second) {
            max = updates[i].second;
        }
        if (max < updates[i].first) {
            max = updates[i].first;
        }
    }

    for (int i = 0; i < max + 1; i++) {
        if (visited[i] == 0) {
            dfs(i);
        }
    }

    size = s.size();
    for (int i = 0; i < size; i++) {
        pos[s[size-i-1]] = i;
        result.push_back(s[size-i-1]);
    }

    for (int i = max; i >= 0; i--) {
        size = graph[i].size();
        for (int j = 0; j < size; j++) {
            if (pos[graph[i][j]] < pos[i] - 1) {
                p = i;
                c = j;
                b = false;
                break;
            }
        }
        if (b == false) {
            break;
        }
    }

    if (b == false) {
        for (int i = pos[graph[p][c]]; i <= pos[p]; i++) {
            falseresult.push_back(result[i]);
        }
        falseresult.push_back(result[pos[graph[p][c]]]);
        return {b, falseresult};
    }



    return {b, {result}}; // This is a dummy return value. YOU SHOULD CHANGE THIS!
}

