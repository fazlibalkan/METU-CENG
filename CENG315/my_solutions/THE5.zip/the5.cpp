#include "the5.h"
// do not add extra libraries here

/*
W: the width of the field
L: the length of the field
partitions: 2D Boolean array for partitions, if a partition of w x l exists then partitions[x][y] is true.
numberOfCalls/numberOfIterations: method specific control parameter
*/

int recursiveMethod(int W, int L, bool** partitions, int* numberOfCalls){
    (*numberOfCalls)++;
    
    int first_min, second_min, width_min = 600, length_min = 600, result;
    
    if (partitions[W][L] == true) {
        return 0;
    } else {
        for (int M = 1; M <= (W)/2; M++) {
             first_min = recursiveMethod(W-M, L, partitions, numberOfCalls) + recursiveMethod(M,L, partitions, numberOfCalls);
             if (width_min > first_min) {
                 width_min = first_min;
             }
        }
        
        for (int N = 1; N <= (L)/2; N++) {
            second_min = recursiveMethod(W, L-N, partitions, numberOfCalls) + recursiveMethod(W, N, partitions, numberOfCalls);
            if (length_min > second_min) {
                 length_min = second_min;
             }
        }
        
        if (width_min < length_min) {
            result = std::min(width_min, W*L);
        } else {
            result = std::min(length_min, W*L);
        }
        
    }
    
    
	return result; // this is a dummy return value. YOU SHOULD CHANGE THIS!
}

int memoizationHelper(int W, int L, bool** partitions, int* numberOfCalls, int **mem) {
    (*numberOfCalls)++;
    
    int first_min, second_min, width_min = 600, length_min = 600, result;
    
    if (partitions[W][L] == true) {
        mem[W][L] = 0;
        return 0;
    } else {
        if (mem[W][L] == -1) {
            for (int M = 1; M <= (W)/2; M++) {
                 first_min = memoizationHelper(W-M, L, partitions, numberOfCalls, mem) + memoizationHelper(M,L, partitions, numberOfCalls, mem);
                 if (width_min > first_min) {
                     width_min = first_min;
                 }
            }
            
            for (int N = 1; N <= (L)/2; N++) {
                second_min = memoizationHelper(W, L-N, partitions, numberOfCalls, mem) + memoizationHelper(W, N, partitions, numberOfCalls, mem);
                if (length_min > second_min) {
                     length_min = second_min;
                 }
            }
            
            if (width_min < length_min) {
                result = std::min(width_min, W*L);
            } else {
                result = std::min(length_min, W*L);
            }
            
            mem[W][L] = result;
            return result;
            
        } else {
            return mem[W][L];
        }
        
    }
    
}
int memoizationMethod(int W, int L, bool** partitions, int* numberOfCalls){
    (*numberOfCalls)++;
    int** mem = new int*[W+1];
	for(int i = 0; i < W+1; i++){
		mem[i] = new int[L+1];
		for (int j = 0; j < L+1; j++){
			mem[i][j] = -1;
		}
	}
	return memoizationHelper(W, L, partitions, numberOfCalls, mem); // this is a dummy return value. YOU SHOULD CHANGE THIS!
}

int bottomUpMethod(int W, int L, bool** partitions, int* numberOfIterations){
    int first_min, second_min, width_min = 600, length_min = 600, result;
    
    int** mem = new int*[W+1];
	for(int i = 0; i < W+1; i++){
	    mem[i] = new int[L+1];
	    for (int j = 0; j < L+1; j++){
            mem[i][j] = i*j;
		}
	}
	
	for (int i = 1; i < W + 1 ; i++) {
	    for (int j = 1; j < L + 1 ; j++) {
	        if (partitions[i][j] == true) {
	            mem[i][j] = 0;
	            continue;
	        } else {
	            width_min = 600; length_min = 600;
	            for (int M = 1; M <= i; M++) {
                    (* numberOfIterations)++;
                    
                    first_min =  mem[i-M][j] + mem[M][j];
                    if (width_min > first_min) {
                        width_min = first_min;
                    }
                }
                
                for (int N = 1; N <= j; N++) {
                    (* numberOfIterations)++;
                    
                    second_min = mem[i][j-N] + mem[i][N];
                    if (length_min > second_min) {
                        length_min = second_min;
                    }
                }
                
            
                if (width_min < length_min) {
                    result = std::min(width_min, mem[i][j]);
                } else {
                    result = std::min(length_min, mem[i][j]);
                }
                
                mem[i][j] = result;
	        }
    	}
	}
    
	return result; // this is a dummy return value. YOU SHOULD CHANGE THIS!
}
