#include "the3.h"

// do not add extra libraries here


/*
    arr       : array to be sorted, in order to get points this array should contain be in sorted state before returning
    ascending : true for ascending, false for descending 
    n         : number of elements in the array
    l         : the number of characters used in counting sort at each time
    
    you can use ceil function from cmath
    
*/

int countSort(std::string * arr, bool ascending, int n, int l, int d, int & iter) {
    
    std::string * output = new std::string[n];
    int size = (int)pow(26, l);
    int i, count[size] = {0};
    int index = 0, digit = 1;
    
    for (i = 0; i < n; i++) {
        digit = 1;
        index = 0;
        for (int c = l - 1; c >= 0; c--) {
            index += digit * ((int)(arr[i][d - l + 1 + c]) - 65);
            digit *= 26;
        }
        
        if (ascending) {
            count[index]++;
        } else {
            count[size - index - 1]++;
        }
        iter++;
    }
    
    for (i = 1; i < size; i++) {
        count[i] += count[i-1];
        iter++;
    }
    
    
    for (i = n-1; i >= 0; i--) {
        digit = 1;
        index = 0;
        for (int c = l - 1; c >= 0; c--) {
            index += digit * ((int)(arr[i][d - l + 1 + c]) - 65);
            digit *= 26;
        }
        
        if (ascending) {
            output[count[index] - 1] = arr[i];
            count[index]--;
        } else {
            output[count[size - index - 1] - 1] = arr[i];
            count[size - index - 1]--;
        }
        
        iter++;
    }
    
    for (i = 0; i < n; i++) {
        arr[i] = output[i];
        
        iter++;
    }
    
    return 0;
}

int radixSort(std::string arr[], bool ascending, int n, int l){
    int str_len = arr[0].length();
    int iter = 0;
    
    for (int i = 0; i < str_len; i+=l) {
        iter++;
        if (str_len - i < l) {
            countSort(arr, ascending, n, str_len - i, str_len-1-i, iter);
        } else {
            countSort(arr, ascending, n, l, str_len-1-i, iter);
        }
    }
    return iter;    
    
}
