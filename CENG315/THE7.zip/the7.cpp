#include "the7.h"


void FindRoute(int n, std::vector<Road> roads, int s, int d, int x, int y) {
  // You can change these variables. These are here for demo only.
  std::vector<int> path;
  std::vector<int> path11;
  std::vector<int> path21;
  std::vector<int> path22;
  std::vector<int> path12;
  std::vector<int> pathxy;
  int cost = INT_MAX;
  // Write your code here...
  int graph[n][n];
  
  int distance[n];
  bool final[n];
  int parent[n];
  int min = INT_MAX, min_index, u;
  
  int cost11, cost12, cost21, cost22, costxy;
  
  int road_length = roads.size();
  
  for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        graph[i][j] = INT_MAX;
    }
  }
  for (int i = 0; i < road_length; i++) {
      graph[roads[i].endpoints.first][roads[i].endpoints.second] = roads[i].time;
      graph[roads[i].endpoints.second][roads[i].endpoints.first] = roads[i].time;
  }
  
  //first dijkstra for s->x and s->y
  for (int i = 0; i < n; i++) {
      distance[i] = INT_MAX;
      final[i] = false;
  }
  parent[s] = -1;
  distance[s] = 0;
  min = INT_MAX;
  
  for (int c = 0; c < n-1; c++) {
      //pick min
      min = INT_MAX;
      for (int i = 0; i < n; i++) {
          if (final[i] == false && distance[i] < min) {
              min = distance[i];
              min_index = i;
          }
      }
      u = min_index;
      final[u] = true;
      
      for (int v = 0; v < n; v++) {
          if (!final[v] && graph[u][v] != INT_MAX && distance[u] + graph[u][v] < distance[v]) {
              parent[v] = u;
              distance[v] = distance[u] + graph[u][v];
          }
      }
  }
  
  //printing
  int i = x;
  while (i != -1) {
      path11.push_back(i);
      i = parent[i];
  }
  i = y;
  while (i != -1) {
      path21.push_back(i);
      i = parent[i];
  }
  
  cost11 = distance[x];
  cost21 = distance[y];
  
  //----------------------------------------------------------------------------------
  
  //second dijkstra for x->d 
  for (int i = 0; i < n; i++) {
      distance[i] = INT_MAX;
      final[i] = false;
  }
  parent[x] = -1;
  distance[x] = 0;
  min = INT_MAX;
  
  for (int c = 0; c < n-1; c++) {
      //pick min
      min = INT_MAX;
      for (int i = 0; i < n; i++) {
          if (final[i] == false && distance[i] < min) {
              min = distance[i];
              min_index = i;
          }
      }
      u = min_index;
      final[u] = true;
      
      for (int v = 0; v < n; v++) {
          if (!final[v] && graph[u][v] != INT_MAX && distance[u] + graph[u][v] < distance[v]) {
              parent[v] = u;
              distance[v] = distance[u] + graph[u][v];
          }
      }
  }
  //printing
  i = d;
  while (i != -1) {
      path22.push_back(i);
      i = parent[i];
  }
  
  cost22 = distance[d];
  
  //----------------------------------------------------------------------------------
  
  //third dijkstra for y->d 
  for (int i = 0; i < n; i++) {
      distance[i] = INT_MAX;
      final[i] = false;
  }
  parent[y] = -1;
  distance[y] = 0;
  min = INT_MAX;
  
  for (int c = 0; c < n-1; c++) {
      //pick min
      min = INT_MAX;
      for (int i = 0; i < n; i++) {
          if (final[i] == false && distance[i] < min) {
              min = distance[i];
              min_index = i;
          }
      }
      u = min_index;
      final[u] = true;
      
      for (int v = 0; v < n; v++) {
          if (!final[v] && graph[u][v] != INT_MAX && distance[u] + graph[u][v] < distance[v]) {
              parent[v] = u;
              distance[v] = distance[u] + graph[u][v];
          }
      }
  }
  //printing
  i = d;
  while (i != -1) {
      path12.push_back(i);
      i = parent[i];
  }
  
  cost12 = distance[d];
  
  
   
  //----------------------------------------------------------------------------------
  
  //last dijkstra for x->y 
  for (int i = 0; i < n; i++) {
      distance[i] = INT_MAX;
      final[i] = false;
  }
  parent[y] = -1;
  distance[y] = 0;
  
  
  for (int c = 0; c < n-1; c++) {
      //pick min
      min = INT_MAX;
      for (int i = 0; i < n; i++) {
          if (final[i] == false && distance[i] < min) {
              min = distance[i];
              min_index = i;
          }
      }
      u = min_index;
      final[u] = true;
      
      for (int v = 0; v < n; v++) {
          if (!final[v] && graph[u][v] != INT_MAX && distance[u] + graph[u][v] < distance[v]) {
              
              parent[v] = u;
              distance[v] = distance[u] + graph[u][v];
          }
      }
  }
  //printing
  i = x;
  while (i != -1) {
      pathxy.push_back(i);
      i = parent[i];
  }
  
  costxy = distance[x];
  
  //checking
  if (cost11 + cost12 + costxy < cost21 + cost22 + costxy) {
      cost = cost11 + cost12 + costxy;
      i = path11.size();
      for (int c = 0; c < i; c++) {
          path.push_back(path11[i-c-1]);
      }
      i = pathxy.size();
      for (int c = 1; c < i - 1; c++) {
          path.push_back(pathxy[c]);
      }
      i = path12.size();
      for (int c = 0; c < i; c++) {
          path.push_back(path12[i-c-1]);
      }
  } else {
      cost = cost21 + cost22 + costxy;
      i = path21.size();
      for (int c = 0; c < i; c++) {
          path.push_back(path21[i-c-1]);
      }
      i = pathxy.size();
      for (int c = 1; c < i - 1; c++) {
          path.push_back(pathxy[i-c-1]);
      }
      i = path22.size();
      for (int c = 0; c < i; c++) {
          path.push_back(path22[i-c-1]);
      }
  }
  

  // Your output should be like this. You can change this as long as you keep
  // the output format. PrintRange function helps you print elements of
  // containers with iteratos (e.g., std::vector).
  std::cout << cost << " ";
  PrintRange(path.begin(), path.end());
  std::cout << std::endl;
}