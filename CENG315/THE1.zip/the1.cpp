#include "the1.h"

//You can add your own helper functions

int sillySortHelper(int* arr, long &comparison, long & swap, int size, int start, int end) {
    int num_of_calls = 1;
    
    if (size < 4) {
	    if (size == 2) {
	        if (arr[start] > arr[end]) {
	            int temp = arr[start];
	            arr[start] = arr[end];
	            arr[end] = temp;
	            swap++;
	        }
	        comparison++;
	    } else if (size == 3) {
	        for (int i = 0; i < 2; i++) {
	            if (arr[start + i] > arr[end - 1 + i]) {
	                int temp = arr[start + i];
	                arr[start + i] = arr[end - 1 + i];
	                arr[end - 1 + i] = temp;
	                swap++;
	            }
	            comparison++;
	        }
	    }
	} else if (size >= 4) {
	    //num_of_calls += 6;
	    num_of_calls += sillySortHelper(arr, comparison, swap, size/2, start, start + (end - start)/2); // q1 and q2
	    num_of_calls += sillySortHelper(arr, comparison, swap, size/2, start + (end - start)/4 + 1, start + 3*(end - start)/4); // q2 and q3 
	    num_of_calls += sillySortHelper(arr, comparison, swap, size/2, start + (end - start)/2 + 1, end); // q3 and q4
	    num_of_calls += sillySortHelper(arr, comparison, swap, size/2, start, start + (end - start)/2); // q1 and q2
	    num_of_calls += sillySortHelper(arr, comparison, swap, size/2, start + (end - start)/4 + 1, start + 3*(end - start)/4); // q2 and q3 
	    num_of_calls += sillySortHelper(arr, comparison, swap, size/2, start, start + (end - start)/2); // q1 and q2
	}
	
	return num_of_calls;
    
}

void merge(int *arr, long &comparison, int size, int start1, int end1, int start2, int end2, int type) {
    if (type == 0) {
        int n1 = end1 - start1 + 1;
        int n2 = end2 - start2 + 1;
        int arr1[n1], arr2[n2];
        int i = 0, j = 0, k = start1;
        
        for (int a = 0; a < n1; a++) {
            arr1[a] = arr[start1 + a];
        }
        for (int a = 0; a < n2; a++) {
            arr2[a] = arr[start2 + a];
        }
        
        while (i < n1 && j < n2) {
            if (k == end1 + 1) {
                k = start2;
            }
            if (arr1[i] <= arr2[j]) {
                //original array changed to arr1[i]
                arr[k] = arr1[i];
                i++;
                comparison++;
            } else {
                //original array changed to arr2[j]
                arr[k] = arr2[j];
                j++;
                comparison++;
            }
            k++;
        }
        
        while (i < n1) {
            if (k == end1 + 1) {
                k = start2;
            }
            arr[k] = arr1[i];
            i++;
            k++;
        }
        while (j < n2) {
            if (k == end1 + 1) {
                k = start2;
            }
            arr[k] = arr2[j];
            j++;
            k++;
        }
        
    } else {
        //last merge: merge the h1 (q1 and q3 in arr) and h2 (q2 and q4 in arr)
        int n1 = (end1 - start1 + 1)*2;
        int n2 = (end2 - start2 + 1)*2;
        int arr1[n1], arr2[n2];
        int i = 0, j = 0, k = start1;
        
        for (int a = 0; a < n1/2; a++) {
            arr1[a] = arr[start1 + a];
        }
        for (int a = 0; a < n1/2; a++) {
            arr1[n1/2 + a] = arr[start2 + a];
        }
        for (int a = 0; a < n2/2; a++) {
            arr2[a] = arr[end1 + 1 + a];
        }
        for (int a = 0; a < n2/2; a++) {
            arr2[n2/2 + a] = arr[end2 + 1 + a];
        }
        
        
        while (i < n1 && j < n2) {
            if (arr1[i] <= arr2[j]) {
                //original array changed to arr1[i]
                arr[k] = arr1[i];
                i++;
                comparison++;
            } else {
                //original array changed to arr2[j]
                arr[k] = arr2[j];
                j++;
                comparison++;
            }
            
            k++;
        }
        while (i < n1) {
            arr[k] = arr1[i];
            i++;
            k++;
        }
        while (j < n2) {
            arr[k] = arr2[j];
            j++;
            k++;
        }
    }
    
}

int crossMergeSortHelper(int *arr, long &comparison, int size, int start, int end) {
    int num_of_calls=1;
    
    if (size == 1) {
        //do nothing
    } else if (size == 2) {
        //compare and swap
        if (arr[start] > arr[end]) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
        }
        comparison++;
    } else {
        int m1 = start + (end - start) / 4, m2 = start + (end - start) / 2, m3 = start + 3 * (end - start) / 4;
        //recursive calls
        num_of_calls += crossMergeSortHelper(arr, comparison, size / 4, start, start + (end - start) / 4);
        num_of_calls += crossMergeSortHelper(arr, comparison, size / 4, start + (end - start) / 4 + 1, start + (end - start) / 2);
        num_of_calls += crossMergeSortHelper(arr, comparison, size / 4, start + (end - start) / 2 + 1, start + 3 * (end - start) / 4);
        num_of_calls += crossMergeSortHelper(arr, comparison, size / 4, start + 3 * (end - start) / 4 + 1, end);
        
        //merging!
        merge(arr, comparison, size, start, m1, m2 + 1, m3, 0); // type 0
        merge(arr, comparison, size, m1 + 1, m2, m3 + 1, end, 0); //type 0
        merge(arr, comparison, size, start, m1, m2 + 1, m3, 1); //type 1
        
    }
    return num_of_calls;
}

int sillySort(int* arr, long &comparison, long & swap, int size) 
{
    
    int num_of_calls=1;
	
	//Your code here
	
	num_of_calls += sillySortHelper(arr, comparison, swap, size, 0, size - 1);
	num_of_calls--;
	return num_of_calls;
}


int crossMergeSort(int *arr, long &comparison, int size)
{
	
	int num_of_calls=1;
	
	// Your code here
	num_of_calls += crossMergeSortHelper(arr, comparison, size, 0, size-1);
	num_of_calls--;
	return num_of_calls;
	
}