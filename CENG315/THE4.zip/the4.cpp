#include "the4.h"


int recursive_sln(int i, int*& arr, int &number_of_calls){ //direct recursive
    number_of_calls+=1;
    
    int m = 0, x, y;
    //your code here
    if(i == 0) return arr[0];
    if (i == 1) return (arr[1]>arr[0]?arr[1]:arr[0]);
    if (i == 2) {
        m = (arr[1]>arr[0]?arr[1]:arr[0]);
        if (arr[2] > m) {
            m = arr[2];
        }
        return m;
    }
    
    x = recursive_sln(i-3, arr, number_of_calls) + arr[i];
    y = recursive_sln(i-1, arr, number_of_calls);

    return ((x>y)?x:y); // this is a dummy return value. YOU SHOULD CHANGE THIS!
}



int memoization_sln(int i, int*& arr, int*& mem){ //memoization

    //your code here
    int m = 0, x, y;
    if(i == 0){
         mem[i] = arr[0];
         return mem[i];
    }
    if (i == 1){
        mem[0] = arr[0];
        mem[i] = (arr[1]>arr[0]?arr[1]:arr[0]);
        return mem[i];
    } 
    if (i == 2) {
        mem[0] = arr[0];
        m = (arr[1]>arr[0]?arr[1]:arr[0]);
        mem[1] = m;
        if (arr[2] > m) {
            m = arr[2];
        }
        mem[i] = m;
        return mem[i];
    }
    
    if (mem[i-3] == -1){
        x = memoization_sln(i-3, arr, mem) + arr[i];
    } else {
        x = mem[i-3] + arr[i];
    }
    
    if (mem[i-1] == -1){
        y = memoization_sln(i-1, arr, mem);
    } else {
        y = mem[i-1];
    }
    
    mem[i] = ((x>y)?x:y);

    return mem[i]; // this is a dummy return value. YOU SHOULD CHANGE THIS!
}



int dp_sln(int size, int*& arr, int*& mem){ //dynamic programming

    //your code here
    int m;
    if (size > 0) mem[0] = arr[0]; //0
    if (size > 1) mem[1] = (arr[1]>arr[0]?arr[1]:arr[0]); //1
    if (size > 2) {
        m = (arr[1]>arr[0]?arr[1]:arr[0]); //2
        if (arr[2] > m) {
            m = arr[2];
        }   
        mem[2] = m;
    }
    
    for (int i = 3; i < size; i++)  {
        mem[i] = ((mem[i-3] + arr[i] > mem[i-1])?mem[i-3] + arr[i]:mem[i-1]);
    }
    

    return mem[size-1]; // this is a dummy return value. YOU SHOULD CHANGE THIS!
}

