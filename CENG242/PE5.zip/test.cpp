#include <iostream>
#include "path_tracker.h"

int main()
{
    int existing_path1[6] = {2, 4, 2, -4, -2, -4};
    int existing_path2[6] = {2, 4, 2, -4, -2, -4};
    PathTracker pt1 = PathTracker(existing_path1, 3);
    PathTracker pt2 = PathTracker(existing_path2, 3);

    pt1.summary();
    pt2.summary();
    
    std::cout << "Comparing Displacements" << std::endl;
    std::cout << "pt1 == pt2: " << (pt1 == pt2) << "\n";
    std::cout << "pt1 > pt2: " << (pt1 > pt2) << "\n";
    std::cout << "pt1 < pt2: " << (pt1 < pt2) << "\n";

    // notice that distance can be compared with a floating-point
    // not another PathTracker object.
    std::cout << "distance comparison: " << (pt1 == pt2.distance) << "\n";

    return 0;
}
