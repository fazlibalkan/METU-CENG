% CHANGES DONE TO THIS FILE WILL BE OVERWRITTEN. 
% IT WILL HAVE NO EFFECT ON YOUR GRADE.

:- module(kb, [person/3]).

% person(Name, Age, Hobbies)
person(joseph, 27, reading).
person(jessica, 32, crafting).
person(michael, 22, reading).
person(william, 33, reading).
person(elizabeth, 30, television).
person(jennifer, 38, crafting).
person(patricia, 33, bird_watching).
person(charles, 39, bird_watching).
person(david, 31, bird_watching).
person(mary, 25, crafting).
person(barbara, 25, reading).
person(richard, 32, travelling).
person(james, 22, fishing).
person(susan, 32, reading).
person(karen, 40, bird_watching).
person(sarah, 25, crafting).
person(linda, 21, reading).
person(john, 28, reading).
person(thomas, 23, bird_watching).
person(robert, 22, television).