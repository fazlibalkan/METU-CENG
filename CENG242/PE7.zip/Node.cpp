#include "Node.h"

// // // THE FRIEND METHODS ARE ALREADY IMPLEMENTED. // // //
// // // // // // // DO NOT CHANGE THEM! // // // // // // //

Node::Node(int id) {
	// TODO
	this->id = id;
}

Node::~Node() {
	// TODO
	int size = this->children.size();
	
	for (int i = 0; i < size; i++) {
	    delete (this->children)[size-i-1];
	    (this->children).pop_back();
	}
	
	
	
}

Node::Node(const Node& node) {
	// TODO
	int size = this->children.size();
	Node * nd;
	
	this->id = node.id;
	
	for (int i = 0; i < size; i++) {
	    nd = new Node(*((node.children)[i]));
	    (this->children).push_back(nd);
	}
	
	
}

int Node::getId() const {
	// TODO
	return this->id;
}

char Node::getData() const {
	// TODO
	throw InvalidRequest();
}

vector<Node*>& Node::getChildren() {
	// TODO
	return children;
}

void Node::operator+=(Node& childNode) {
	// TODO
	this->children.push_back(&childNode);
}

Node* Node::operator&(const Node& node) const {
	// TODO
	DataNode * nd;
	try {
	    this->getData();
	    node.getData();
	    
	    nd = new DataNode(node, node.getData());
	    return nd;
	} catch (InvalidRequest e) {
	    try {
    	    this->getData();
    	    
    	    nd = new DataNode(node, this->getData());
    	    return nd;
    	} catch (InvalidRequest e) {
    	    try {
        	    node.getData();
        	    
        	    nd = new DataNode(node, node.getData());
        	    return nd;
        	} catch (InvalidRequest e) {
        	    Node * n = new Node(node);
        	    return n;
        	}
    	}
	}
	
}

// This is already implemented for you, do NOT change it!
ostream& operator<<(ostream& os, const Node& node) {
	try {
		node.getData();
		os << *(DataNode*)&node;
	}
	catch (InvalidRequest e) {
		os << "[" << node.id;
		for (int i = 0; i < node.children.size(); i++)
			os << ", " << *node.children[i];
		os << "]";
	}
	return os;
}


/*************** DataNode *****************/

DataNode::DataNode(int id, char data) : Node(id) {
	// TODO
	this->id = id;
	this->data = data;
}

DataNode::~DataNode() {
	// TODO
	int size = this->children.size();
	for (int i = 0; i < size; i++) {
	    delete (this->children)[size-i-1];
	    (this->children).pop_back();
	}
}

DataNode::DataNode(const DataNode& dataNode): Node(dataNode) {
	// TODO
	int size = this->children.size();
	Node * nd;
	
	this->id = dataNode.id;
	this->data = dataNode.data;
	
	for (int i = 0; i < size; i++) {
	    nd = new Node(*((dataNode.children)[i]));
	    (this->children).push_back(nd);
	}
}

DataNode::DataNode(const Node& node, char data) : Node(node) {
	// TODO
	int size;
	Node * n = new Node(node);
	DataNode * dn = new DataNode(n->getId(), data);
	
	size = n->getChildren().size();
	
	for (int i = 0; i < size; i++) {
	    dn->getChildren().push_back((n->getChildren())[i]);
	}
	n->getChildren().clear();
	delete n;
}

char DataNode::getData() const {
	// TODO
	return this->data;
}

// This is already implemented for you, do NOT change it!
ostream& operator<<(ostream& os, const DataNode& dataNode) {
	os << "[" << "(" << dataNode.id << ", \'" << dataNode.data << "\')";
	for (int i = 0; i < dataNode.children.size(); i++)
		os << ", " << *dataNode.children[i];
	os << "]";
	return os;
}

