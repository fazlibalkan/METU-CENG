
#include "NodeManager.h"

NodeManager::NodeManager() {
	// TODO
}

NodeManager::~NodeManager() {
	// TODO
	int size = this->startingNodes.size();
	
	for (int i = 0; i < size; i++) {
	    delete (this->startingNodes)[size-i-1];
	    this->startingNodes.pop_back();
	}
}

void NodeManager::addRelation(int parent, int child) {
	// TODO
	int size = this->startingNodes.size(), pfound = 0, cfound = 0;
	Node * p;
	Node * c;
	
	for (int i = 0; i < size; i++) {
	    vector<Node*> stack;
        stack.push_back(((this->startingNodes)[i]));
        
        if (pfound && cfound) break;
        
        while(stack.size() != 0) {
            Node * temp = stack[stack.size() - 1];
            stack.pop_back();
            
            if (!pfound && (temp->getId() == parent)) {
                pfound = 1;
                p = temp;
            }
            if (!cfound && (temp->getId() == child)) {
                cfound = 1;
                c = temp;
            }
            
            for (int a = 0; a < temp->getChildren().size(); a++) {
	           stack.push_back((temp->getChildren())[a]);
            }
	    }
    }
	
    if (pfound && cfound) {
        p->getChildren().push_back(c);
        for (int i = 0; i < size; i++) {
            if ((this->startingNodes)[i] == c) {
                (this->startingNodes).erase((this->startingNodes).begin()+i);
            }
        }
    } else if(pfound) {
        c = new Node(child);
        p->getChildren().push_back(c);
    } else if (cfound) {
        p = new Node(parent);
        p->getChildren().push_back(c);
        for (int i = 0; i < size; i++) {
            if ((this->startingNodes)[i] == c) {
                (this->startingNodes)[i] = p;
            }
        }
    } else {
        p = new Node(parent);
        c = new Node(child);
        p->getChildren().push_back(c);
        this->startingNodes.push_back(p);
    }
}

void NodeManager::setDataToNode(int id, char data) {
	// TODO
	int size = this->startingNodes.size(), idfound = 0, s;
	Node * temp, *temptemp;
	DataNode *dn;
	for (int i = 0; i < size; i++) {
	    vector<Node*> stack;
        stack.push_back(((this->startingNodes)[i]));
        
        while(stack.size() != 0) {
            temp = stack[stack.size() - 1];
            
            stack.pop_back();
            
            if (temp->getId() == id) {
                idfound = i;
                dn = new DataNode(id, data);
               (this->startingNodes).push_back(dn);
                    
                s = temp->getChildren().size();
                for (int x = 0; x < s; x++) {
                    dn->getChildren().push_back((temp->getChildren())[s - x - 1]);
                }
                temp->getChildren().clear();
                delete temp;
                (this->startingNodes).erase((this->startingNodes).begin()+i);
                return;
            }
            
            for (int a = 0; a < temp->getChildren().size(); a++) {
                temptemp = (temp->getChildren())[a];
                
                if (temptemp->getId() == id) {
                    idfound = i;
                    dn = new DataNode(id, data);
                    temp->getChildren().push_back(dn);
                    
                    s = temptemp->getChildren().size();
                    for (int x = 0; x < s; x++) {
                        dn->getChildren().push_back((temptemp->getChildren())[s - x - 1]);
                    }
                    temptemp->getChildren().clear();
                    temp->getChildren().erase(temp->getChildren().begin()+a);
                    delete temptemp;
                    return;
                }
	            stack.push_back((temp->getChildren())[a]);
            }
	    }
    }
    
    if (idfound == 0) {
        temp = new DataNode(id, data);
        this->startingNodes.push_back(temp);
    }
}

const Node& NodeManager::getNode(int id) {
	// TODO
	int size = this->startingNodes.size(), idfound = 0;
	
	for (int i = 0; i < size; i++) {
	    vector<Node*> stack;
        stack.push_back(((this->startingNodes)[i]));
        
        if (idfound) break;
        
        while(stack.size() != 0) {
            Node * temp = stack[stack.size() - 1];
            stack.pop_back();
            
            if (temp->getId() == id) {
                idfound = 1;
                return *temp;
            }
            
            for (int a = 0; a < temp->getChildren().size(); a++) {
	           stack.push_back((temp->getChildren())[a]);
            }
	    }
    }
	
}