#include <iostream>
#include "office.h"
#include "owner.h"

using namespace std;

Office::Office(const string &property_name, int area, Owner *owner, bool having_wifi, bool having_reception)
{
    this->property_name = property_name;
    this->area = area;
    this->having_wifi = having_wifi;
    this->having_reception = having_reception;
    if (owner) {
        owner->add_property(this);
    }
    this->owner = owner;
}

float Office::valuate()
{
    float mult = 1;
    
    if (having_wifi) mult *= 1.3;
    if (having_reception) mult *= 1.5;
    
    return this->area * 5.0 * mult;
}