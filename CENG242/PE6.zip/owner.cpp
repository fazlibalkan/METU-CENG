#include <iostream>
#include <string>
#include <vector>
#include "owner.h"

using namespace std;

Owner::Owner()
{
}

Owner::Owner(const string &name, float balance)
{
    this->name = name;
    this->balance = balance;
}

void Owner::print_info()
{
}

string &Owner::get_name()
{
    return this->name;
}

void Owner::add_property(Property *property)
{
    properties.push_back(property);
}

void Owner::buy(Property *property, Owner *seller)
{
    bool inprops = false;
    int s = seller->properties.size(), ind = -1;
    for (int i = 0; i < s; i++) {
        if (seller->properties[i] == property) {
            inprops = true;
            ind = i;
        }
    }
    cout << "[BUY] Property: " << property->get_name() << " Value: "<< property->valuate() << "$ " << seller->get_name() << "--->" << this->name << endl;
        
    if (this->balance < property->valuate()) {
        cout << "[ERROR] Unaffordable  property" << endl;
    } else if (!inprops) {
        cout << "[ERROR] Transaction  on  unowned  property" << endl;
    } else {
        seller->balance += property->valuate();
        this->balance -= property->valuate();
        this->add_property(property);
        seller->properties.erase(seller->properties.begin()+ind);
    }
    
    
}

void Owner::sell(Property *property, Owner *owner)
{
    bool inprops = false;
    int s = this->properties.size(), ind = -1;
    for (int i = 0; i < s; i++) {
        if (this->properties[i] == property) {
            inprops = true;
            ind = i;
        }
    }
    cout << "[SELL] Property: " << property->get_name() << " Value: "<< property->valuate() << "$ " << this->name << "--->" << owner->get_name() << endl;
    if (owner->balance < property->valuate()) {
        cout << "[ERROR] Unaffordable  property" << endl;
    } else if (!inprops) {
        cout << "[ERROR] Transaction  on  unowned  property" << endl;
    } else {
        this->balance += property->valuate();
        owner->balance -= property->valuate();
        owner->add_property(property);
        this->properties.erase(this->properties.begin()+ind);
    }
    
}

void Owner::list_properties()
{
    int s = properties.size();
    cout << "Properties of " << get_name() << ":" << endl;
    cout << "Balance: " << this->balance << "$" << endl;
    
    for (int i = 0; i < s; i++) {
        cout << i+1 << ". " << properties[i]->get_name() << endl;
    }
}