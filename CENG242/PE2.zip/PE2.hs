module PE2 where

---------------------------------------------------------------------------------------------
------------------------- DO NOT CHANGE ABOVE OR FUNCTION SIGNATURES-------------------------
--------------- DUMMY IMPLEMENTATIONS ARE GIVEN TO PROVIDE A COMPILABLE TEMPLATE ------------
--------------------- REPLACE THEM WITH YOUR COMPILABLE IMPLEMENTATIONS ---------------------
---------------------------------------------------------------------------------------------

-- Note: undefined is a value that causes an error when evaluated. Replace it with
-- a viable definition! Name your arguments as you like by changing the holes: _

--------------------------
-- Part I: Time to inf up!

-- naturals: The infinite list of natural numbers. That's it!
naturals :: [Integer]
naturals = 0 : [v | x <- [1..], v <- [x]]

-- interleave: Interleave two lists, cutting off on the shorter list.
interleave :: [a] -> [a] -> [a]
interleave f [] = []
interleave [] s = []
interleave (f:fl) (s:sl) = f : s : interleave fl sl

-- integers: The infinite list of integers. Ordered as [0, -1, 1, -2, 2, -3, 3, -4, 4...].
integers :: [Integer]
integers = 0 : [v | x <- [1..], v <- [-x, x]]

--------------------------------
-- Part II: SJSON Prettification

firstIndex :: Char -> String -> Int -> Int
firstIndex c str num | str == "" = num
                     | c == head str = num
                     | otherwise = firstIndex c (tail str) (num + 1)

-- splitOn: Split string on first occurence of character.
splitOn :: Char -> String -> (String, String)
splitOn c str = (take (firstIndex c str 0) str, drop ((firstIndex c str 0) + 1) str)

-- tokenizeS: Transform an SJSON string into a list of tokens.
tokenizeS :: String -> [String]
tokenizeS (s:sl) | sl == "" = []
                 | s == '{' = "{":[] ++ tokenizeS sl
                 | s == '}' = "}":[] ++ tokenizeS sl
                 | s == ':' = ":":[] ++ tokenizeS sl
                 | s == ',' = ",":[] ++ tokenizeS sl
                 | s == '\'' = (fst (splitOn s sl)):[] ++ tokenizeS (snd (splitOn s sl))
                 | otherwise = tokenizeS sl

-- prettifyS: Prettify SJSON, better tokenize first!

helperPrettifyS :: [String] -> Int -> String
helperPrettifyS (f:rest) n | rest == [] = "\n" ++ (take (4*(n-1)) (cycle " ")) ++ f
                           | f == "{" =  "{" ++"\n" ++ (take (4*(n+1)) (cycle " ")) ++ (helperPrettifyS rest (n+1)) 
                           | f == "}" = "\n" ++ (take (4*(n-1)) (cycle " ")) ++ "}" ++ (helperPrettifyS rest (n-1))
                           | f == ":" = ": " ++ (helperPrettifyS rest n)
                           | f == "," = "," ++ "\n" ++ (take (4*n) (cycle " ")) ++ (helperPrettifyS rest n)
                           | otherwise = "'" ++ f ++ "'" ++ (helperPrettifyS rest n)

prettifyS :: String -> String
prettifyS str = helperPrettifyS (tokenizeS str) 0

-- Good luck to you, friend and colleague!

