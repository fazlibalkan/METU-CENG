module PE3 where

data Cell = SpaceCraft Int | Sand | Rock Int | Pit deriving (Eq, Read, Show)

type Grid = [[Cell]]
type Coordinate = (Int, Int)

data Move = North | East | South | West | PickUp | PutDown deriving (Eq, Read, Show)

data Robot = Robot { name :: String,
                     location :: Coordinate,
                     capacity :: Int,
                     energy :: Int,
                     storage :: Int } deriving (Read, Show)

-------------------------------------------------------------------------------------------
--------------------------------- DO NOT CHANGE ABOVE -------------------------------------
------------- DUMMY IMPLEMENTATIONS ARE GIVEN TO PROVIDE A COMPILABLE TEMPLATE ------------
------------------- REPLACE THEM WITH YOUR COMPILABLE IMPLEMENTATIONS ---------------------
-------------------------------------------------------------------------------------------
-------------------------------------- PART I ---------------------------------------------

isInGrid :: Grid -> Coordinate -> Bool
isInGrid grid coor | fst coor < 0 || snd coor < 0 = False
                   | length grid <= snd coor = False
                   | length (head grid) <= fst coor = False
                   | otherwise = True

-------------------------------------------------------------------------------------------

rockCount :: Cell -> Int
rockCount (Rock n ) = n
rockCount _ = 0

totalCountRow :: [Cell] -> Int
totalCountRow row | row == [] = 0
                  | otherwise = rockCount (head row) + totalCountRow (tail row)

totalCount :: Grid -> Int
totalCount grid | grid == [] = 0
                | otherwise = totalCountRow (head grid) + totalCount (tail grid)

-------------------------------------------------------------------------------------------

isPitCoor :: Cell -> Coordinate -> Bool
isPitCoor (Pit) coor = True
isPitCoor _ coor = False

coordinatesOfPits :: Grid -> [Coordinate]
coordinatesOfPits [] = []
coordinatesOfPits grid = [ (x, y) |  x <- [0..((length (head grid))-1)], y <- [0..((length (grid)) - 1)], isPitCoor ((grid !! y) !! x) (x, y) == True]

-------------------------------------------------------------------------------------------

move :: Move -> Coordinate -> Coordinate
move North loc = (fst loc, snd loc - 1)
move South loc = (fst loc, snd loc + 1)
move East loc = (fst loc + 1, snd loc)
move West loc = (fst loc - 1, snd loc)
move PickUp loc = (fst loc, snd loc)
move PutDown loc = (fst loc, snd loc)

reduce :: Move -> (Int, Int)
reduce North = (1, 0)
reduce South = (1, 0)
reduce East = (1, 0)
reduce West = (1, 0)
reduce PickUp = (5, -1)
reduce PutDown = (3, 1)

traveling :: Grid -> Coordinate -> Robot -> [Move] -> Int -> Int -> [Coordinate]
traveling grid loc robot (x:xs) e s | isInGrid grid loc == False = [loc]  ++ traveling grid loc robot xs (e - 1) s
                                    | xs == [] && loc `elem` (coordinatesOfPits grid) = [loc]
                                    | xs == [] = [move x loc]
                                    | loc `elem` (coordinatesOfPits grid) = [loc] ++ traveling grid loc robot xs 0 s
                                    | e == 0 = [loc] ++ traveling grid loc robot xs 0 s
                                    | s <= (-1) = [loc] ++ traveling grid loc robot xs (e - fst (reduce x)) (-1)
                                    | otherwise = [move x loc] ++ traveling grid (move x loc) robot xs (e - fst (reduce x)) (s - snd (reduce x))
                                   
tracePath :: Grid -> Robot -> [Move] -> [Coordinate]
tracePath grid robot moves = traveling grid (location robot) robot moves (energy robot) (storage robot)

------------------------------------- PART II ----------------------------------------------

gain :: Robot -> Coordinate -> Coordinate -> Int
gain r robot spacec | energy(r) + (100 - ((abs (fst robot - fst spacec) + abs (snd robot - snd spacec)) * 20)) > 100 = 100
                    | energy(r) +  (100 - ((abs (fst robot - fst spacec) + abs (snd robot - snd spacec)) * 20)) < 0 = 0
                    | otherwise = energy(r) + (100 - ((abs (fst robot - fst spacec) + abs (snd robot - snd spacec)) * 20))

isSpaceCCoor :: Cell -> Bool
isSpaceCCoor (SpaceCraft n) = True
isSpaceCCoor _  = False

coordinateOfSpaceC :: Grid -> [Coordinate]
coordinateOfSpaceC [] = []
coordinateOfSpaceC grid = [ (x, y) |  x <- [0..((length (head grid))-1)], y <- [0..((length (grid)) - 1)], isSpaceCCoor ((grid !! y) !! x)  == True]


energiseRobots :: Grid -> [Robot] -> [Robot]
energiseRobots grid robots = [robot{energy = (gain (robot) (location robot) ((coordinateOfSpaceC grid)!!0))} | robot <- robots]

-------------------------------------------------------------------------------------------

updateGrid grid coor cell = [[if (x, y) == coor then cell else ((grid !! y) !! x) |  x <- [0..((length (head grid))-1)]] | y <- [0..((length (grid)) - 1)]]

changeCell :: Cell-> Cell
changeCell (SpaceCraft n) = SpaceCraft (n+1)
changeCell (Rock n) = Rock (n-1)

giveCell :: Cell -> Int
giveCell (SpaceCraft n) = n
giveCell (Rock n) = n

reduceEnergy :: Robot -> Int
reduceEnergy robot = (energy robot) - 1

reduceEnergy5 :: Robot -> Int
reduceEnergy5 robot = (energy robot) - 5

reduceEnergy3 :: Robot -> Int
reduceEnergy3 robot = (energy robot) - 3

reduceStorage :: Robot -> Int
reduceStorage robot = (storage robot) - 1

increaseStorage :: Robot -> Int
increaseStorage robot = (storage robot) + 1

applying :: Grid -> Coordinate -> Robot -> [Move] -> (Grid, Robot)
applying grid loc robot (x:xs) | energy robot == 0 = (grid, robot)
                               | storage robot <= -1 = (grid, robot)
                               | xs == [] && loc `elem` (coordinatesOfPits grid) = (grid, robot{energy = reduceEnergy robot})
                               | loc `elem` (coordinatesOfPits grid) = applying grid loc (robot{energy = reduceEnergy robot}) xs
                               | xs == [] && loc `elem` (coordinateOfSpaceC grid) = (grid , robot{energy=reduceEnergy robot})
                               | x == East || x == West || x == North || x == South = applying grid (move x loc) (robot{location = (move x loc), energy = reduceEnergy robot}) xs
                               | x == PickUp && giveCell (grid!!(fst loc)!!(snd loc)) == 0 = (grid, robot{energy=reduceEnergy5 robot})
                               | x == PickUp  = applying (updateGrid grid loc (changeCell (grid!!(fst loc)!!(snd loc)))) loc (robot{energy = reduceEnergy5 robot, storage = increaseStorage robot}) xs
                               | x == PutDown && giveCell (grid!!(fst loc)!!(snd loc)) >= capacity robot = (grid, robot{energy=reduceEnergy3 robot})
                               | x == PutDown = applying (updateGrid grid loc (changeCell (grid!!(fst loc)!!(snd loc)))) loc (robot{energy = reduceEnergy3 robot, storage = reduceStorage robot}) xs
                               | xs == [] = (grid , robot{energy=reduceEnergy robot})
                               | otherwise = (grid, robot{energy=reduceEnergy robot})

applyMoves :: Grid -> Robot -> [Move] -> (Grid, Robot)
applyMoves grid robot moves = applying grid (location robot) robot moves 

--updateGrid grid (0, 0) (Rock 2)


