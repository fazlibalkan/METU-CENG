module PE1 where

import Text.Printf


-- This function takes a Double and rounds it to 2 decimal places as requested in the PE --
getRounded :: Double -> Double
getRounded x = read s :: Double
               where s = printf "%.2f" x

-------------------------------------------------------------------------------------------
----------------------- DO NOT CHANGE ABOVE OR FUNCTION SIGNATURES-------------------------
------------- DUMMY IMPLEMENTATIONS ARE GIVEN TO PROVIDE A COMPILABLE TEMPLATE ------------
------------------- REPLACE THEM WITH YOUR COMPILABLE IMPLEMENTATIONS ---------------------
-------------------------------------------------------------------------------------------

convertTL :: Double -> String -> Double
convertTL money "USD" = getRounded ( money / 8.18 )
convertTL money "EUR" = getRounded ( money / 9.62 )
convertTL money "BTC" = getRounded ( money / 473497.31 )


-------------------------------------------------------------------------------------------

countOnWatch :: [String] -> String -> Int -> Int
countOnWatch _ _ 0 = 0
countOnWatch schedule employee days
    |head schedule == employee = 1 + countOnWatch (tail schedule) employee (days - 1)
    |otherwise = countOnWatch (tail schedule) employee (days - 1)
    
-------------------------------------------------------------------------------------------

operations :: Int -> Int
operations a
    | ((a `rem` 10) `rem` 3 == 0) = ((a - 1)`rem` 10)
    | ((a `rem` 10) `rem` 4 == 0) = ((a * 2) `rem` 10)
    | ((a `rem` 10) `rem` 5 == 0) = ((a + 3) `rem` 10)
    | otherwise = ((a + 4) `rem` 10)

encrypt :: Int -> Int
encrypt x
    | x == 0 = 0
    |(x < 10) = 1000 * (operations x)
    |(x < 100) = (100 * (operations x)) + encrypt (x `div` 10)
    |(x < 1000) = (10 * (operations x)) + encrypt (x `div` 10)
    |otherwise = (operations x) + encrypt (x `div` 10)


-------------------------------------------------------------------------------------------

calc :: (Double, Int) -> Double
calc b
    | (fst b >= 10000) && (snd b >= 2) = getRounded ((fst b) * (1 +  (0.115 / 12))^(12 * (snd b)))
    | (fst b >= 10000) && (snd b < 2) = getRounded ((fst b) * (1 +  (0.105 / 12))^(12 * (snd b)))
    | (fst b < 10000) && (snd b >= 2) = getRounded ((fst b) * (1 +  (0.095 / 12))^(12 * (snd b)))
    | (fst b < 10000) && (snd b < 2) = getRounded ((fst b) * (1 +  (0.09 / 12))^(12 * (snd b)))

compoundInterests :: [(Double, Int)] -> [Double]
compoundInterests investments = map calc investments
